// Browser fallback for the GitHub Pages website. The APK build replaces this file
// with the bundled Capacitor App and Browser plugin bridge.
window.ChallengerNativePlugins = window.ChallengerNativePlugins || {};
