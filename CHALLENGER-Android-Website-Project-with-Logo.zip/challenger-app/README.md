# CHALLENGER — Website + Android APK

This package keeps the supplied CHALLENGER HTML as the app's main UI and adds a Capacitor Android wrapper. Google sign-in in the APK opens the system browser and returns to the app through `challengerapp://login-callback`.

## 1. Supabase redirect allowlist (required)

In Supabase Dashboard → Authentication → URL Configuration → Additional Redirect URLs, add:

```
challengerapp://login-callback
```

Keep your existing Supabase Project URL, publishable/anon key, Google provider settings and database unchanged. The Google OAuth provider's authorized redirect URI remains the Supabase callback shown in Supabase's Google provider setup, usually `https://YOUR_PROJECT_REF.supabase.co/auth/v1/callback`.

## 2. Create the GitHub repository

Create a **public** repository named `challenger-app`, upload all files in this folder, and commit them to the `main` branch.

GitHub Pages: Settings → Pages → Deploy from a branch → `main` → `/ (root)`. The website URL is `https://YOUR_GITHUB_USERNAME.github.io/challenger-app/`.

## 3. Build APK

The included GitHub Actions workflow builds the APK automatically on every push to `main`, or manually from Actions → Build CHALLENGER Android APK → Run workflow. Download `challenger-apk` from the completed run's Artifacts section.

## Notes

- `index.html` preserves the supplied website. The only intended login changes are the Android plugin bridge and APK deep-link callback.
- Native Capacitor plugins are bundled into `www/native-plugins.js`; this fixes plugin imports for the static HTML app.
- The APK workflow uses a debug build suitable for testing and direct installation. A Play Store release requires a separately signed release build.
- No Supabase service-role key is included. Do not put secret keys in the HTML or this repository.
